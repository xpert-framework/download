#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.dao.tabelas.impl;

import ${package}.application.BaseDAOImpl;
import ${package}.dao.tabelas.MunicipioDAO;
import ${package}.modelo.tabelas.Municipio;
import javax.ejb.Stateless;

/**
 *
 * @author ayslanms
 */
@Stateless
public class MunicipioDAOImpl extends BaseDAOImpl<Municipio> implements MunicipioDAO {

    @Override
    public Class getEntityClass() {
        return Municipio.class;
    }

}
