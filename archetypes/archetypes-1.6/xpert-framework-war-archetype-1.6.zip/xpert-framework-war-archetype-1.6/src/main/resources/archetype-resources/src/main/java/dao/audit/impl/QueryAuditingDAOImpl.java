#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.dao.audit.impl;

import ${package}.application.BaseDAOImpl;
import ${package}.dao.audit.QueryAuditingDAO;
import ${package}.modelo.audit.QueryAuditing;
import javax.ejb.Stateless;

/**
 *
 * @author Ayslan
 */
@Stateless
public class QueryAuditingDAOImpl extends BaseDAOImpl<QueryAuditing> implements QueryAuditingDAO {

    @Override
    public Class getEntityClass() {
        return QueryAuditing.class;
    }
    
    
    
}
