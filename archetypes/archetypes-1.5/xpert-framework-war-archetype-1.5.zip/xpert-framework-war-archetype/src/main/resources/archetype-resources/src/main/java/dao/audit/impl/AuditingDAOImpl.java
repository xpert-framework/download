#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.dao.audit.impl;

import ${package}.application.BaseDAOImpl;
import ${package}.dao.audit.AuditingDAO;
import ${package}.modelo.audit.Auditing;
import javax.ejb.Stateless;

/**
 *
 * @author Ayslan
 */
@Stateless
public class AuditingDAOImpl extends BaseDAOImpl<Auditing> implements AuditingDAO {

    @Override
    public Class getEntityClass() {
        return Auditing.class;
    }
    
    
    
}
