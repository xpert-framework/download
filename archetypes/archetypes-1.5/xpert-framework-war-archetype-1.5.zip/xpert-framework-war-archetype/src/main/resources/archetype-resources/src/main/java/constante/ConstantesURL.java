#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ${package}.constante;

/**
 *
 * @author Ayslan
 */
public class ConstantesURL {

    public static final String URL_APLICACAO = "http://localhost:8080/${artifactId}";
}
