#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.mb.padrao;

import javax.faces.bean.ManagedBean;

/**
 * Classe que retorna os valores das enums
 *
 * @author Ayslan
 */
@ManagedBean
public class EnumMB {

}