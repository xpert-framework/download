#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.dao.tabelas.impl;

import ${package}.application.BaseDAOImpl;
import ${package}.dao.tabelas.UfDAO;
import ${package}.modelo.tabelas.Uf;
import javax.ejb.Stateless;

/**
 *
 * @author ayslanms
 */
@Stateless
public class UfDAOImpl extends BaseDAOImpl<Uf> implements UfDAO {

    @Override
    public Class getEntityClass() {
        return Uf.class;
    }

}
