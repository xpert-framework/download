#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.dao.tabelas;

import com.xpert.persistence.dao.BaseDAO;
import ${package}.modelo.tabelas.Uf;
import javax.ejb.Local;

/**
 *
 * @author ayslanms
 */
@Local
public interface UfDAO extends BaseDAO<Uf> {
    
}
